import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:permission_handler/permission_handler.dart';
import 'package:video_player/video_player.dart';
import 'package:image_gallery_saver/image_gallery_saver.dart';
import 'package:path_provider/path_provider.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const StatusSaverApp());
}

class StatusSaverApp extends StatelessWidget {
  const StatusSaverApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Musa ✅ WhatsApp",
      theme: ThemeData(useMaterial3: true),
      home: const HomePage(),
    );
  }
}

class StatusItem {
  final File file;
  final String sourceDir;
  StatusItem(this.file, this.sourceDir);
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<StatusItem> _items = [];
  bool _loading = false;

  final _knownPkgs = const <String>[
    'com.whatsapp',
    'com.whatsapp.w4b',
    'com.whatsapp.w4b2',
    'com.gbwhatsapp',
    'com.yowhatsapp',
    'com.fmwhatsapp',
    'com.wa.clone',
    'com.whatsapp.clone',
  ];  

  @override
  void initState() {
    super.initState();
    _scanAll();
  }

  Future<void> _askPerms() async {
    await [
      Permission.photos,
      Permission.videos,
      Permission.storage,
    ].request();

    if (await Permission.manageExternalStorage.isDenied) {
      await Permission.manageExternalStorage.request();
    }
  }

  Future<void> _scanAll() async {
    if (!mounted) return;
    setState(() => _loading = true);
    await _askPerms();

    final roots = await _discoverStorageRoots();
    final Set<Directory> statusDirs = {};

    for (final root in roots) {
      for (final pkg in _knownPkgs) {
        final base = Directory('$root/Android/media/$pkg');
        if (!await base.exists()) continue;
        try {
          await for (final ent in base.list(recursive: true, followLinks: false)) {
            if (ent is Directory && p.basename(ent.path) == '.Statuses') {
              statusDirs.add(ent);
            }
          }
        } catch (_) {}
      }
    }

    for (final root in roots) {
      for (final candidate in <String>[
        '$root/WhatsApp/Media/.Statuses',
        '$root/WhatsApp Business/Media/.Statuses',
        '$root/GBWhatsApp/Media/.Statuses',
        '$root/YoWhatsApp/Media/.Statuses',
        '$root/FMWhatsApp/Media/.Statuses',
      ]) {
        final d = Directory(candidate);
        if (await d.exists()) statusDirs.add(d);
      }
    }

    final items = <StatusItem>[];
    for (final dir in statusDirs) {
      try {
        final files = dir
            .listSync()
            .whereType<File>() 
            .where((f) {
              final ext = p.extension(f.path).toLowerCase();
              return ['.jpg', '.jpeg', '.png', '.webp', '.mp4', '.mov', '.m4v'].contains(ext);
            })
            .toList();
        for (final f in files) {
          items.add(StatusItem(f, dir.path));
        }
      } catch (_) {}
    }

    items.sort((a, b) => b.file.statSync().modified.compareTo(a.file.statSync().modified));

    if (!mounted) return;
    setState(() {
      _items = items;
      _loading = false;
    });

    if (items.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("لا توجد حالات بعد. افتح الحالات في واتساب ثم اضغط تحديث.")),
      );
    }
  }

  Future<List<String>> _discoverStorageRoots() async {
    final roots = <String>{'/storage/emulated/0'};
    try {
      final storageRoot = Directory('/storage');
      if (await storageRoot.exists()) {
        for (final ent in storageRoot.listSync()) {
          if (ent is Directory) {
            final name = p.basename(ent.path).toLowerCase();
            if (name.contains('self')) continue;
            roots.add(ent.path);
          }
        }
      }
    } catch (_) {}
    return roots.toList();
  }

  bool _isVideo(File f) {
    final ext = p.extension(f.path).toLowerCase();
    return ['.mp4', '.mov', '.m4v'].contains(ext);
  }

  Future<void> _saveToGallery(File f) async {
    final bytes = await f.readAsBytes();
    final res = await ImageGallerySaver.saveImage(
      bytes,
      quality: 100,
      name: "Status_${DateTime.now().millisecondsSinceEpoch}${p.extension(f.path)}",
    );
    final ok = (res is Map && (res['isSuccess'] == true || res['success'] == true));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(ok ? "تم الحفظ في المعرض." : "تعذر الحفظ.")),
    );
  }

  Future<void> _exportCopy(File f) async {
    final dir = await getExternalStorageDirectory();
    final outDir = Directory(p.join(dir!.path, 'StatusSaver'));
    if (!await outDir.exists()) await outDir.create(recursive: true);
    final out = File(p.join(outDir.path, p.basename(f.path)));
    await f.copy(out.path);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("تم النسخ إلى: ${out.path}")),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Musa ✅ WhatsApp"),
        actions: [
          IconButton(onPressed: _scanAll, icon: const Icon(Icons.refresh), tooltip: "تحديث"),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _items.isEmpty
              ? const Center(child: Text("افتح الحالات في واتساب ثم اضغط تحديث."))
              : GridView.builder(
                  padding: const EdgeInsets.all(10),
                  itemCount: _items.length,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3, mainAxisSpacing: 8, crossAxisSpacing: 8),
                  itemBuilder: (context, i) {
                    final it = _items[i];
                    return GestureDetector(
                      onLongPress: () => _showActions(it),
                      onTap: () => Navigator.push(context,
                          MaterialPageRoute(builder: (_) => _PreviewPage(item: it))),
                      child: GridTile(
                        footer: Container(
                          color: Colors.black45,
                          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                          child: Text(
                            p.basename(p.dirname(it.sourceDir)),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(color: Colors.white, fontSize: 11),
                          ),
                        ),
                        child: _isVideo(it.file)
                            ? const ColoredBox(color: Colors.black12, child: Icon(Icons.play_circle))
                            : Image.file(it.file, fit: BoxFit.cover),
                      ),
                    );
                  },
                ),
    );
  }

  void _showActions(StatusItem it) {
    showModalBottomSheet(
      context: context,
      builder: (_) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.save_alt),
              title: const Text("حفظ في المعرض"),
              onTap: () async {
                Navigator.pop(context);
                await _saveToGallery(it.file);
              },
            ),
            ListTile(
              leading: const Icon(Icons.copy_all),
              title: const Text("نسخ إلى مجلد StatusSaver"),
              onTap: () async {
                Navigator.pop(context);
                await _exportCopy(it.file);
              },
            ),
            ListTile(
              leading: const Icon(Icons.folder),
              title: Text("المصدر: ${it.sourceDir}"),
              onTap: () {},
            ),
          ],
        ),
      ),
    );
  }
}

class _PreviewPage extends StatefulWidget {
  final StatusItem item;
  const _PreviewPage({required this.item});
  @override
  State<_PreviewPage> createState() => _PreviewPageState();
}

class _PreviewPageState extends State<_PreviewPage> {
  VideoPlayerController? _vc;

  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.item.file)) {
      _vc = VideoPlayerController.file(widget.item.file)
        ..initialize().then((_) {
          setState(() {});
          _vc?.play();
        });
    }
  }

  bool _isVideo(File f) {
    final ext = p.extension(f.path).toLowerCase();
    return ['.mp4', '.mov', '.m4v'].contains(ext);
  }

  @override
  void dispose() {
    _vc?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final f = widget.item.file;
    return Scaffold(
      appBar: AppBar(title: Text(p.basename(f.path))),
      body: Center(
        child: _isVideo(f)
            ? (_vc?.value.isInitialized == true
                ? AspectRatio(aspectRatio: _vc!.value.aspectRatio, child: VideoPlayer(_vc!))
                : const CircularProgressIndicator())
            : Image.file(f),
      ),
    );
  }
}
