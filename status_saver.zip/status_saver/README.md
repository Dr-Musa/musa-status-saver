# Musa ✅ WhatsApp — Status Saver (APK)

**مهم:** لصناعة APK بشكل سريع:
1) ثبّت Flutter و Android SDK.
2) أنشئ مشروعًا فارغًا باسم `status_saver`:
   ```bash
   flutter create status_saver
   ```
3) انسخ الملفات من هذا الأرشيف فوق المشروع:
   - `pubspec.yaml` → استبدل الملف.
   - `lib/main.dart` → استبدل الملف.
   - `android/app/src/main/AndroidManifest.xml` → استبدل الملف.
   - `android/app/build.gradle` → استبدل الملف.
4) ثم نفّذ:
   ```bash
   flutter pub get
   flutter build apk --release
   ```
5) ستحصل على:
   `build/app/outputs/flutter-apk/Musa_WhatsApp.apk`

> ملاحظة: الاسم الظاهر للتطبيق داخل النظام هو **"Musa ✅ WhatsApp"**. اسم ملف الخرج تم ضبطه مسبقًا.

### أذونات
- يحتاج إذن **الوصول إلى كل الملفات** على أندرويد 11+ لالتقاط جميع مسارات `.Statuses` لكل نسخ واتساب.
- إذا لم تظهر الحالات، افتحها داخل واتساب أولًا ثم اضغط "تحديث" داخل التطبيق.

بالتوفيق 🌟
